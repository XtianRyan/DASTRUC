using System.Data;
using Microsoft.Data.SqlClient;

namespace appsdev_maglasang
{
    public partial class Form1 : Form
    {
        private string _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Appsdev-Maglasang;";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataLoad();
        }
        private void DataLoad()
        {
            string query = "SELECT * FROM [User]";
            SqlDataAdapter da = new(query, _connectionString);
            DataSet ds = new();
            da.Fill(ds, "User");
            dataGridView1.DataSource = ds.Tables["User"].DefaultView;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string age = textBox2.Text;
            string newId = (dataGridView1.RowCount + 1).ToString(); // Increment the ID

            string query = $"INSERT INTO [User] (Id, Name, Age) VALUES ('{newId}','{name}','{age}')";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    DataLoad(); // Refresh data after insertion
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error : {ex.Message}");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string value1 = textBox3.Text;
            string value2 = textBox4.Text;
            string identifier = textBox5.Text; // Get the ID of the record to update

            string query = $"UPDATE [User] SET Id = '{value1}', Name = '{value2}' WHERE Id = '{identifier}'";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    DataLoad(); // Refresh data after update
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error : {ex.Message}");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string identifier = textBox6.Text; // Get the ID of the record to delete

            string query = $"DELETE FROM [User] WHERE Id = '{identifier}'";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    DataLoad(); // Refresh data after deletion
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error : {ex.Message}");
                }
            }
        }
    }
}

